using Danps.Core;
using Microsoft.AspNetCore.Mvc;
using PocketEntity.Core.Models;
using PocketEntity.Core.Services;
using PocketEntity.Core.ViewModels;

namespace PocketEntity.Core.Controllers
{
    [Route("api/v1/[controller]")]
    public class NaturezaController : FactoryControllerBase<Naturezas, NaturezaViewModel>
    {
        public NaturezaController(QuickPocketContext context, INaturezaService servico) : base(context, servico)
        {
        }
    }
}