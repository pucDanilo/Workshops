using Danps.Core;
using Microsoft.AspNetCore.Mvc;
using PocketEntity.Core.Models;
using PocketEntity.Core.Services;
using PocketEntity.Core.ViewModels;

namespace PocketEntity.Core.Controllers
{
    [Route("api/v1/[controller]")]
    public class TransacaoController : FactoryControllerBase<Transacaos, TransacaoViewModel>
    {
        public TransacaoController(QuickPocketContext context, ITransacaoService servico) : base(context, servico)
        {
        }
    }
}