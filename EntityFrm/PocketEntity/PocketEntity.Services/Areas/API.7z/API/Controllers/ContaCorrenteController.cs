using Danps.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PocketEntity.Core.Models;
using PocketEntity.Core.Services;
using PocketEntity.Core.ViewModels;

namespace PocketEntity.Core.Controllers
{
    [Authorize]
    [Route("api/v1/[controller]")]
    public class ContaCorrenteController : FactoryControllerBase<ContaCorrentes, ContaCorrenteViewModel>
    {
        public ContaCorrenteController(QuickPocketContext context, IContaCorrenteService servico) : base(context, servico)
        {
        }
    }
}