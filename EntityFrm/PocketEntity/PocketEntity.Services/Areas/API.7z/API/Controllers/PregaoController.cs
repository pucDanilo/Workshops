using Danps.Core;
using Microsoft.AspNetCore.Mvc;
using PocketEntity.Core.Models;
using PocketEntity.Core.Services;
using PocketEntity.Core.ViewModels;

namespace PocketEntity.Core.Controllers
{
    [Route("api/v1/[controller]")]
    public class PregaoController : FactoryControllerBase<Pregaos, PregaoViewModel>
    {
        public PregaoController(QuickPocketContext context, IPregaoService servico) : base(context, servico)
        {
        }
    }
}