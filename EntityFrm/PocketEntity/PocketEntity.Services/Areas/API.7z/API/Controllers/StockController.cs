using Danps.Core;
using Microsoft.AspNetCore.Mvc;
using PocketEntity.Core.Models;
using PocketEntity.Core.Services;
using PocketEntity.Core.ViewModels;

namespace PocketEntity.Core.Controllers
{
    [Route("api/v1/[controller]")]
    public class StockController : FactoryControllerBase<Stocks, StockViewModel>
    {
        public StockController(QuickPocketContext context, IStockService servico) : base(context, servico)
        {
        }
    }
}