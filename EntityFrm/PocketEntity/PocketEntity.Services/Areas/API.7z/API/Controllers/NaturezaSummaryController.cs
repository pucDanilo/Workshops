using Danps.Core;
using Microsoft.AspNetCore.Mvc;
using PocketEntity.Core.Models;
using PocketEntity.Core.Services;
using PocketEntity.Core.ViewModels;

namespace PocketEntity.Core.Controllers
{
    [Route("api/v1/[controller]")]
    public class NaturezaSummaryController : FactoryControllerBase<NaturezaSummary, NaturezaSummaryViewModel>
    {
        public NaturezaSummaryController(QuickPocketContext context, INaturezaSummaryService servico) : base(context, servico)
        {
        }
    }
}