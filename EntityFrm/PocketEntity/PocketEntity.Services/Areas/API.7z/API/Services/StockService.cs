using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface IStockService : IServiceFactory<Stocks, StockViewModel>
    {
    }

    public class StockService : ServiceFactory<Stocks, StockViewModel>, IStockService
    {
        public StockService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapStockViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(Stocks obj, StockViewModel model)
        {
            obj.ContaCorrenteId = model.ContaCorrenteId;
            obj.Codigo = model.Codigo;
            obj.Nome = model.Nome;
            obj.DataCotacao = model.DataCotacao;
            obj.Cotacao = model.Cotacao;
            obj.Quantidade = model.Quantidade;
            obj.PrecoMedio = model.PrecoMedio;
            obj.GanhoTotal = model.GanhoTotal;
            obj.Total = model.Total;
        }

        public override System.Linq.Expressions.Expression<System.Func<Stocks, bool>> GetById(Int32 StockId)
        {
            return a =>
        a.StockId == StockId;
        }

        public override Expression<System.Func<Stocks, object>> IncludeGetAll()
        {
            return a => a.ContaCorrentes;
        }

        public override Expression<Func<Stocks, bool>> GetByViewModel(StockViewModel model)
        {
            return a => a.ContaCorrenteId == model.ContaCorrenteId;
        }

        public override Expression<Func<Stocks, object>> OrderByClause()
        {
            return a => a.StockId;
        }
    }
}