using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface ITransacaoService : IServiceFactory<Transacaos, TransacaoViewModel>
    {
    }

    public class TransacaoService : ServiceFactory<Transacaos, TransacaoViewModel>, ITransacaoService
    {
        public TransacaoService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapTransacaoViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(Transacaos obj, TransacaoViewModel model)
        {
            obj.TransacaoId = model.TransacaoId;
            obj.ContaCorrenteId = model.ContaCorrenteId;
            obj.NaturezaId = model.NaturezaId;
            obj.Descricao = model.Descricao;
            obj.Data = model.Data;
            obj.Valor = model.Valor;
            obj.TenantId = model.TenantId;
        }

        public override System.Linq.Expressions.Expression<System.Func<Transacaos, bool>> GetById(Int32 TransacaoId)
        {
            return a =>
        a.TransacaoId == TransacaoId;
        }

        public override Expression<System.Func<Transacaos, object>> IncludeGetAll()
        {
            return a => a.ContaCorrentes;
        }

        public override Expression<Func<Transacaos, bool>> GetByViewModel(TransacaoViewModel model)
        {
            return a => a.ContaCorrenteId == model.ContaCorrenteId;
        }

        public override Expression<Func<Transacaos, object>> OrderByClause()
        {
            return a => a.TransacaoId;
        }
    }
}