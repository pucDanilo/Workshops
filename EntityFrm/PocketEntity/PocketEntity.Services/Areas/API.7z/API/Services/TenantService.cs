using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface ITenantService : IServiceFactory<Tenants, TenantViewModel>
    {
    }

    public class TenantService : ServiceFactory<Tenants, TenantViewModel>, ITenantService
    {
        public TenantService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapTenantViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(Tenants obj, TenantViewModel model)
        {
            obj.TenantName = model.TenantName;
        }

        public override System.Linq.Expressions.Expression<System.Func<Tenants, bool>> GetById(Int32 TenantId)
        {
            return a =>
        a.TenantId == TenantId;
        }

        public override Expression<System.Func<Tenants, object>> IncludeGetAll()
        {
            return a => a.ContaCorrentes;
        }

        public override Expression<Func<Tenants, bool>> GetByViewModel(TenantViewModel model)
        {
            return a => a.TenantId == model.TenantId;
        }

        public override Expression<Func<Tenants, object>> OrderByClause()
        {
            return a => a.TenantId;
        }
    }
}