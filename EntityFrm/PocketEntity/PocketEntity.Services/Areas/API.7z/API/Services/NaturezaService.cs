using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface INaturezaService : IServiceFactory<Naturezas, NaturezaViewModel>
    {
    }

    public class NaturezaService : ServiceFactory<Naturezas, NaturezaViewModel>, INaturezaService
    {
        public NaturezaService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapNaturezaViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(Naturezas obj, NaturezaViewModel model)
        {
            obj.Nome = model.Nome;
            obj.TenantId = model.TenantId;
        }

        public override System.Linq.Expressions.Expression<System.Func<Naturezas, bool>> GetById(Int32 NaturezaId)
        {
            return a =>
        a.NaturezaId == NaturezaId;
        }

        public override Expression<System.Func<Naturezas, object>> IncludeGetAll()
        {
            return a => a.Tenants;
        }

        public override Expression<Func<Naturezas, bool>> GetByViewModel(NaturezaViewModel model)
        {
            return a => a.TenantId == model.TenantId;
        }

        public override Expression<Func<Naturezas, object>> OrderByClause()
        {
            return a => a.NaturezaId;
        }
    }
}