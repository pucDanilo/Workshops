using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface IContraChequeService : IServiceFactory<ContraCheques, ContraChequeViewModel>
    {
    }

    public class ContraChequeService : ServiceFactory<ContraCheques, ContraChequeViewModel>, IContraChequeService
    {
        public ContraChequeService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapContraChequeViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(ContraCheques obj, ContraChequeViewModel model)
        {
            obj.TransacaoId = model.TransacaoId;
            obj.NaturezaId = model.NaturezaId;
            obj.Valor = model.Valor;
            obj.TenantId = model.TenantId;
        }

        public override System.Linq.Expressions.Expression<System.Func<ContraCheques, bool>> GetById(Int32 ContraChequeId)
        {
            return a =>
        a.ContraChequeId == ContraChequeId;
        }

        public override Expression<System.Func<ContraCheques, object>> IncludeGetAll()
        {
            return a => a.Transacaos;
        }

        public override Expression<Func<ContraCheques, bool>> GetByViewModel(ContraChequeViewModel model)
        {
            return a => a.TransacaoId == model.TransacaoId;
        }

        public override Expression<Func<ContraCheques, object>> OrderByClause()
        {
            return a => a.ContraChequeId;
        }
    }
}