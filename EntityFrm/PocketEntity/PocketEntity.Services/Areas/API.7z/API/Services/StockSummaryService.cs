using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface IStockSummaryService : IServiceFactory<StockSummary, StockSummaryViewModel>
    {
    }

    public class StockSummaryService : ServiceFactory<StockSummary, StockSummaryViewModel>, IStockSummaryService
    {
        public StockSummaryService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapStockSummaryViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(StockSummary obj, StockSummaryViewModel model)
        {
            obj.Descricao = model.Descricao;
            obj.Total = model.Total;
        }

        public override System.Linq.Expressions.Expression<System.Func<StockSummary, bool>> GetById(Int32 TenantId)
        {
            return a =>
        a.TenantId == TenantId;
        }

        public override Expression<System.Func<StockSummary, object>> IncludeGetAll()
        {
            return null;
        }

        public override Expression<Func<StockSummary, bool>> GetByViewModel(StockSummaryViewModel model)
        {
            return null;
        }

        public override Expression<Func<StockSummary, object>> OrderByClause()
        {
            return a => a.TenantId;
        }
    }
}