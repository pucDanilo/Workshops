using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface ITituloService : IServiceFactory<Titulos, TituloViewModel>
    {
    }

    public class TituloService : ServiceFactory<Titulos, TituloViewModel>, ITituloService
    {
        public TituloService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapTituloViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(Titulos obj, TituloViewModel model)
        {
            obj.ContaCorrenteId = model.ContaCorrenteId;
            obj.Nome = model.Nome;
            obj.Tipo = model.Tipo;
            obj.DataVencimento = model.DataVencimento;
            obj.TaxaAtual = model.TaxaAtual;
            obj.ValorLiquido = model.ValorLiquido;
            obj.ValorInvestido = model.ValorInvestido;
            obj.TenantId = model.TenantId;
        }

        public override System.Linq.Expressions.Expression<System.Func<Titulos, bool>> GetById(Int32 TituloId)
        {
            return a =>
        a.TituloId == TituloId;
        }

        public override Expression<System.Func<Titulos, object>> IncludeGetAll()
        {
            return a => a.Tenants;
        }

        public override Expression<Func<Titulos, bool>> GetByViewModel(TituloViewModel model)
        {
            return a => a.TenantId == model.TenantId;
        }

        public override Expression<Func<Titulos, object>> OrderByClause()
        {
            return a => a.TituloId;
        }
    }
}