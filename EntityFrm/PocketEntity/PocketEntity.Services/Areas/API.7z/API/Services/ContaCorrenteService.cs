using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface IContaCorrenteService : IServiceFactory<ContaCorrentes, ContaCorrenteViewModel>
    {
    }

    public class ContaCorrenteService : ServiceFactory<ContaCorrentes, ContaCorrenteViewModel>, IContaCorrenteService
    {
        public ContaCorrenteService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapContaCorrenteViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(ContaCorrentes obj, ContaCorrenteViewModel model)
        {
            obj.NomeBanco = model.NomeBanco;
            obj.Descricao = model.Descricao;
            obj.NumeroConta = model.NumeroConta;
            obj.Data = model.Data;
            obj.Valor = model.Valor;
            obj.TenantId = model.TenantId;
        }

        public override System.Linq.Expressions.Expression<System.Func<ContaCorrentes, bool>> GetById(Int32 ContaCorrenteId)
        {
            return a =>
        a.ContaCorrenteId == ContaCorrenteId;
        }

        public override Expression<System.Func<ContaCorrentes, object>> IncludeGetAll()
        {
            return a => a.Tenants;
        }

        public override Expression<Func<ContaCorrentes, bool>> GetByViewModel(ContaCorrenteViewModel model)
        {
            return a => a.TenantId == model.TenantId;
        }

        public override Expression<Func<ContaCorrentes, object>> OrderByClause()
        {
            return a => a.ContaCorrenteId;
        }//////
    }
}