
using PocketEntity.Core.Fakes; 
using PocketEntity.Core.Models;

namespace PocketEntity.Core.Services
{
    public interface IApiValueService
    {
        ApiModelo[] GetAll();
        ApiFormulario[] GetFormulario(long idModelo);
        ApiModelo Get(int idFormulario);
    }
    public class ApiValueService : IApiValueService
    {
        public ApiModelo[] GetAll()
        {
            return FakeApiPocket.GetAll();
        }
        public ApiFormulario[] GetFormulario(long idModelo)
        {
            return FakeApiPocket.GetFormulario(idModelo);
        }
        public ApiModelo Get(int idFormulario)
        {
            return FakeApiPocket.GetModelo(1);
        }
    }
}