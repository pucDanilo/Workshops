using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface IContraChequeSummaryService : IServiceFactory<ContraChequeSummary, ContraChequeSummaryViewModel>
    {
    }

    public class ContraChequeSummaryService : ServiceFactory<ContraChequeSummary, ContraChequeSummaryViewModel>, IContraChequeSummaryService
    {
        public ContraChequeSummaryService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapContraChequeSummaryViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(ContraChequeSummary obj, ContraChequeSummaryViewModel model)
        {
            obj.Descricao = model.Descricao;
            obj.Total = model.Total;
        }

        public override System.Linq.Expressions.Expression<System.Func<ContraChequeSummary, bool>> GetById(Int32 TenantId)
        {
            return a =>
        a.TenantId == TenantId;
        }

        public override Expression<System.Func<ContraChequeSummary, object>> IncludeGetAll()
        {
            return null;
        }

        public override Expression<Func<ContraChequeSummary, bool>> GetByViewModel(ContraChequeSummaryViewModel model)
        {
            return null;
        }

        public override Expression<Func<ContraChequeSummary, object>> OrderByClause()
        {
            return a => a.TenantId;
        }
    }
}