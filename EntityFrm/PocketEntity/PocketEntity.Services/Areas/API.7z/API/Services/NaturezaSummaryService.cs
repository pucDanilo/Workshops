using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface INaturezaSummaryService : IServiceFactory<NaturezaSummary, NaturezaSummaryViewModel>
    {
    }

    public class NaturezaSummaryService : ServiceFactory<NaturezaSummary, NaturezaSummaryViewModel>, INaturezaSummaryService
    {
        public NaturezaSummaryService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapNaturezaSummaryViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(NaturezaSummary obj, NaturezaSummaryViewModel model)
        {
            obj.Nome = model.Descricao;
            obj.Total = model.Total;
        }

        public override System.Linq.Expressions.Expression<System.Func<NaturezaSummary, bool>> GetById(Int32 TenantId)
        {
            return a =>
        a.TenantId == TenantId;
        }

        public override Expression<System.Func<NaturezaSummary, object>> IncludeGetAll()
        {
            return null;
        }

        public override Expression<Func<NaturezaSummary, bool>> GetByViewModel(NaturezaSummaryViewModel model)
        {
            return null;
        }

        public override Expression<Func<NaturezaSummary, object>> OrderByClause()
        {
            return a => a.TenantId;
        }
    }
}