using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface IContaCorrenteSummaryService : IServiceFactory<ContaCorrenteSummary, ContaCorrenteSummaryViewModel>
    {
    }

    public class ContaCorrenteSummaryService : ServiceFactory<ContaCorrenteSummary, ContaCorrenteSummaryViewModel>, IContaCorrenteSummaryService
    {
        public ContaCorrenteSummaryService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapContaCorrenteSummaryViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(ContaCorrenteSummary obj, ContaCorrenteSummaryViewModel model)
        {
            obj.Descricao = model.Descricao;
            obj.Total = model.Total;
        }

        public override System.Linq.Expressions.Expression<System.Func<ContaCorrenteSummary, bool>> GetById(Int32 TenantId)
        {
            return a =>
        a.TenantId == TenantId;
        }

        public override Expression<System.Func<ContaCorrenteSummary, object>> IncludeGetAll()
        {
            return null;
        }

        public override Expression<Func<ContaCorrenteSummary, bool>> GetByViewModel(ContaCorrenteSummaryViewModel model)
        {
            return null;
        }

        public override Expression<Func<ContaCorrenteSummary, object>> OrderByClause()
        {
            return a => a.TenantId;
        }
    }
}