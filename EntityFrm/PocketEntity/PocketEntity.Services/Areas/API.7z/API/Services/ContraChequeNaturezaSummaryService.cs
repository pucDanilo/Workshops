using AutoMapper;
using Danps.Core.Models;
using Danps.Core.Services;
using Microsoft.Extensions.Logging;
using PocketEntity.Core.Mappers;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
using System;
using System.Linq.Expressions;

namespace PocketEntity.Core.Services
{
    public interface IContraChequeNaturezaSummaryService : IServiceFactory<ContraChequeNaturezaSummary, ContraChequeNaturezaSummaryViewModel>
    {
    }

    public class ContraChequeNaturezaSummaryService : ServiceFactory<ContraChequeNaturezaSummary, ContraChequeNaturezaSummaryViewModel>, IContraChequeNaturezaSummaryService
    {
        public ContraChequeNaturezaSummaryService(ILogger logger, IUserInfo userInfo, QuickPocketContext context) : base(logger, userInfo, context)
        {
            this._mapper = new MapperConfiguration(cfg => { cfg.MapContraChequeNaturezaSummaryViewModel(); }).CreateMapper();
        }

        public override void UpdateEntity(ContraChequeNaturezaSummary obj, ContraChequeNaturezaSummaryViewModel model)
        {
            obj.Nome = model.Descricao;
            obj.Total = model.Total;
        }

        public override System.Linq.Expressions.Expression<System.Func<ContraChequeNaturezaSummary, bool>> GetById(Int32 TenantId)
        {
            return a =>
        a.TenantId == TenantId;
        }

        public override Expression<System.Func<ContraChequeNaturezaSummary, object>> IncludeGetAll()
        {
            return null;
        }

        public override Expression<Func<ContraChequeNaturezaSummary, bool>> GetByViewModel(ContraChequeNaturezaSummaryViewModel model)
        {
            return null;
        }

        public override Expression<Func<ContraChequeNaturezaSummary, object>> OrderByClause()
        {
            return a => a.TenantId;
        }
    }
}