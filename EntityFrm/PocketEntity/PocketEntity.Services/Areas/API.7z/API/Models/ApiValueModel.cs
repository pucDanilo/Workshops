

using PocketEntity.Core.Fakes;
using System.Collections.Generic;

namespace PocketEntity.Core.Models
{
    public class ApiOption
    {
        public string label;
        public object value;
    }

    public class ApiFormulario
    {
        public long id;
        public string label;
        public string required;
        public ApiOption[] options;
        public string name;
        public string value;
        internal ApiOption[] checkbox;
    }
    public class ApiModelo
    {
        public long id;
        public string Controller;
        public string Servico;
        public virtual ICollection<ApiFormulario> Formulario { get; set; }
    }
}