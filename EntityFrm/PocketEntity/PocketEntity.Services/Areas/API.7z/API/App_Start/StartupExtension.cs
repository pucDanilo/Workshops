
using Microsoft.Extensions.DependencyInjection;
using PocketEntity.Core.Services;

namespace PocketEntity.Core
{
    public static class StartupExtension
    {
        public static void AddDanpsService(this IServiceCollection services)
        {
            services.AddTransient<IContaCorrenteSummaryService, ContaCorrenteSummaryService>();
            services.AddTransient<IContraChequeSummaryService, ContraChequeSummaryService>();
            services.AddTransient<IContraChequeNaturezaSummaryService, ContraChequeNaturezaSummaryService>();
            services.AddTransient<INaturezaSummaryService, NaturezaSummaryService>();
            services.AddTransient<IStockSummaryService, StockSummaryService>();
            services.AddTransient<IContaCorrenteService, ContaCorrenteService>();
            services.AddTransient<IContraChequeService, ContraChequeService>();
            services.AddTransient<INaturezaService, NaturezaService>();
            services.AddTransient<IPregaoService, PregaoService>();
            services.AddTransient<IProtocoloService, ProtocoloService>();
            services.AddTransient<ITenantService, TenantService>();
            services.AddTransient<IStockService, StockService>();
            services.AddTransient<ITituloService, TituloService>();
            services.AddTransient<ITransacaoService, TransacaoService>();
        }
    }
}