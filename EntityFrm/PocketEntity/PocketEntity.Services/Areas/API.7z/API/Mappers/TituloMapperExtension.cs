
using AutoMapper;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
namespace PocketEntity.Core.Mappers
{
    public static class MappingTituloExtension
    {
        public static IMappingExpression<Titulos, TituloViewModel> MapTituloViewModel(this IMapperConfigurationExpression provider)
        {
            var mapa = provider.CreateMap <Titulos, TituloViewModel>()
                .ForMember(dest => dest.ContaCorrenteId, opt => opt.MapFrom(src => src.ContaCorrenteId)) 
                .ForMember(dest => dest.Nome, opt => opt.MapFrom(src => src.Nome)) 
                .ForMember(dest => dest.Tipo, opt => opt.MapFrom(src => src.Tipo)) 
                .ForMember(dest => dest.DataVencimento, opt => opt.MapFrom(src => src.DataVencimento)) 
                .ForMember(dest => dest.TaxaAtual, opt => opt.MapFrom(src => src.TaxaAtual)) 
                .ForMember(dest => dest.ValorLiquido, opt => opt.MapFrom(src => src.ValorLiquido)) 
                .ForMember(dest => dest.ValorInvestido, opt => opt.MapFrom(src => src.ValorInvestido)) 
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId)) 
                .ForMember(dest => dest.NomeTenant, opt => opt.MapFrom(src => src.Tenants.TenantName));
            return mapa;
        }
    }
}// end namespace