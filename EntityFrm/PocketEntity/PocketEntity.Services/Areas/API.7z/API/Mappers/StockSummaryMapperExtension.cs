
using AutoMapper;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
namespace PocketEntity.Core.Mappers
{
    public static class MappingStockSummaryExtension
    {
        public static IMappingExpression<StockSummary, StockSummaryViewModel> MapStockSummaryViewModel(this IMapperConfigurationExpression provider)
        {
            var mapa = provider.CreateMap <StockSummary, StockSummaryViewModel>()
                .ForMember(dest => dest.Descricao, opt => opt.MapFrom(src => src.Descricao)) 
                .ForMember(dest => dest.Total, opt => opt.MapFrom(src => src.Total)) ;
            return mapa;
        }
    }
}// end namespace