
using AutoMapper;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
namespace PocketEntity.Core.Mappers
{
    public static class MappingTenantExtension
    {
        public static IMappingExpression<Tenants, TenantViewModel> MapTenantViewModel(this IMapperConfigurationExpression provider)
        {
            var mapa = provider.CreateMap <Tenants, TenantViewModel>()
                .ForMember(dest => dest.TenantName, opt => opt.MapFrom(src => src.TenantName)) ;
            return mapa;
        }
    }
}// end namespace