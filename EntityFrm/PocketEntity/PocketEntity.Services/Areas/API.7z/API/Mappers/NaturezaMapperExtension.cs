
using AutoMapper;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
namespace PocketEntity.Core.Mappers
{
    public static class MappingNaturezaExtension
    {
        public static IMappingExpression<Naturezas, NaturezaViewModel> MapNaturezaViewModel(this IMapperConfigurationExpression provider)
        {
            var mapa = provider.CreateMap <Naturezas, NaturezaViewModel>()
                .ForMember(dest => dest.Nome, opt => opt.MapFrom(src => src.Nome)) 
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId)) 
                .ForMember(dest => dest.NomeTenant, opt => opt.MapFrom(src => src.Tenants.TenantName));
            return mapa;
        }
    }
}// end namespace