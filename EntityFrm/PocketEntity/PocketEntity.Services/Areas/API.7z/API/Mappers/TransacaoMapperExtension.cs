
using AutoMapper;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;
namespace PocketEntity.Core.Mappers
{
    public static class MappingTransacaoExtension
    {
        public static IMappingExpression<Transacaos, TransacaoViewModel> MapTransacaoViewModel(this IMapperConfigurationExpression provider)
        {
            var mapa = provider.CreateMap <Transacaos, TransacaoViewModel>()
                .ForMember(dest => dest.TransacaoId, opt => opt.MapFrom(src => src.TransacaoId)) 
                .ForMember(dest => dest.ContaCorrenteId, opt => opt.MapFrom(src => src.ContaCorrenteId)) 
                .ForMember(dest => dest.NaturezaId, opt => opt.MapFrom(src => src.NaturezaId)) 
                .ForMember(dest => dest.Descricao, opt => opt.MapFrom(src => src.Descricao)) 
                .ForMember(dest => dest.Data, opt => opt.MapFrom(src => src.Data)) 
                .ForMember(dest => dest.Valor, opt => opt.MapFrom(src => src.Valor)) 
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId)) 
                .ForMember(dest => dest.NomeContaCorrente, opt => opt.MapFrom(src => src.ContaCorrentes.NomeBanco));
            return mapa;
        }
    }
}// end namespace