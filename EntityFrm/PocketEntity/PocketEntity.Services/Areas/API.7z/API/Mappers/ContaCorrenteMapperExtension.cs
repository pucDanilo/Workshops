using AutoMapper;
using PocketEntity.Core.Models;
using PocketEntity.Core.ViewModels;

namespace PocketEntity.Core.Mappers
{
    public static class MappingContaCorrenteExtension
    {
        public static IMappingExpression<ContaCorrentes, ContaCorrenteViewModel> MapContaCorrenteViewModel(this IMapperConfigurationExpression provider)
        {
            var mapa = provider.CreateMap<ContaCorrentes, ContaCorrenteViewModel>()
                .ForMember(dest => dest.NomeBanco, opt => opt.MapFrom(src => src.NomeBanco))
                .ForMember(dest => dest.Descricao, opt => opt.MapFrom(src => src.Descricao))
                .ForMember(dest => dest.NumeroConta, opt => opt.MapFrom(src => src.NumeroConta))
                .ForMember(dest => dest.Data, opt => opt.MapFrom(src => src.Data))
                .ForMember(dest => dest.Valor, opt => opt.MapFrom(src => src.Valor))
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId))
                .ForMember(dest => dest.NomeTenant, opt => opt.MapFrom(src => src.Tenants.TenantName));
            return mapa;
        }
    }
}// end namespace